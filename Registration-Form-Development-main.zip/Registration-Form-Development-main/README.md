# Registration-Form-Development
By-Archita Tripathi 
Work Assigned By- Motion Cut Front End Web developement Week 2 (2024)
Developing a responsive Registration Form Developement With HTML,CSS and JavaScript 
