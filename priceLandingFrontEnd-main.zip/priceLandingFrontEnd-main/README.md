# priceLandingFrontEnd
By -Archita Tripathi 
Task assigned By-Motion Cut Frontend Web Development Internship
Week 1:
Developing a responsive Pricing Landing Page With HTML, CSS and JavaScript for different pricing options.

