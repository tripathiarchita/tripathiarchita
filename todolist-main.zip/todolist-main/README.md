# todolist
Author-Archita Tripathi
Assigned By: Motion Cut Front End Web Development 2024
Building To-Do List  by JavaScript core concepts and for local storage of this webpage Json has been used 

